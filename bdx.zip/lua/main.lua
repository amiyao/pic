function u_kksk(name)
sendText(name,"123123")
-- print("money",lbind("getMoney","steve"))
-- print(lbind("addMoney","steve",114514,"kksk"))
oList_=oList()
for k,v in pairs(oList_) do
	print(k,v)
end
end
function CB(name,dat1,dat2)
print(dat1[2],dat2[1])
GUI(name,"u_a","text1","text2","text3")
return
end
function u_k(name)
GUI(name,"a","text1","text2","text3")
end
if x==1 then

end
